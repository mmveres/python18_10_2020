x = 2
perimeter = 4 * 2
print(perimeter)
