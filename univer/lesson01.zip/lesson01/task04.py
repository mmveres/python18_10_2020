# Ввод 2 чисел с консоли и их сумма
x = float(input("enter x"))
y = float(input("enter y"))
sum = x + y
print("sum =", sum)
