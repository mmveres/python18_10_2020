x = 1      # 1
x = x + 1  # 2
x += 1     # 3
y = "2"
z = x+int(y)
print(z)
