x = 7
print(type(x))
x = 7.0
print(type(x))
x = "a7"
print(type(x))