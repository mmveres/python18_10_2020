age = int(input("enter age"))
time = int(input("enter hour"))
if age > 16 and time < 22:
    print("can by alcohol")
else:
    print("can by cola")