x = 3
print(type(x))
y = 2
print(type(y))
z = x/y
print(type(z))
print(z)