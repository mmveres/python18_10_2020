# Ввод текста с консоли и его печать на екран
name = input("enter name")
print("name= ",name)