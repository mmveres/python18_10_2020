import turtle
turtle.showturtle()
turtle.forward(50)
